package dev.luvia;
import java.util.*;
import net.minecraft.client.Minecraft;
import net.minecraft.client.settings.KeyBinding;
import net.minecraft.client.gui.GuiButton;
import net.minecraft.client.gui.GuiIngameMenu;
import net.minecraft.client.gui.GuiMainMenu;
import net.minecraftforge.client.event.FOVUpdateEvent;
import net.minecraftforge.client.event.GuiScreenEvent;
import net.minecraftforge.client.event.RenderGameOverlayEvent;
import net.minecraftforge.common.MinecraftForge;
import net.minecraftforge.fml.client.registry.ClientRegistry;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.common.Mod.EventHandler;
import net.minecraftforge.fml.common.event.FMLInitializationEvent;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.minecraftforge.fml.common.gameevent.InputEvent;
import net.minecraftforge.fml.common.gameevent.TickEvent;
import org.lwjgl.input.Keyboard;
@Mod(modid = "luvia", name = "Luvia Client", version = "1.0", clientSideOnly = true)
public class Luvia {
    public static final List<Module> modules = new ArrayList<>();
    static Modules.Zoom zoom;
    KeyBinding menuKey = new KeyBinding("Luvia Menu", Keyboard.KEY_RSHIFT, "Luvia Client");
    @EventHandler public void init(FMLInitializationEvent e) {
        ClientRegistry.registerKeyBinding(menuKey);
        zoom = new Modules.Zoom();
        modules.addAll(Arrays.asList(new Modules.Fps(), new Modules.Cps(), new Modules.Coords(), new Modules.Keys(), new Modules.Armor(),
            new Modules.ToggleSprint(), new Modules.Fullbright(), zoom));
        MinecraftForge.EVENT_BUS.register(this);
    }
    @SubscribeEvent public void key(InputEvent.KeyInputEvent e) { if (menuKey.isPressed()) Minecraft.getMinecraft().displayGuiScreen(new LuviaMenu()); }
    @SubscribeEvent public void tick(TickEvent.ClientTickEvent e) { if (e.phase == TickEvent.Phase.END && Minecraft.getMinecraft().thePlayer != null) for (Module m : modules) if (m.on) m.tick(); }
    @SubscribeEvent public void hud(RenderGameOverlayEvent.Post e) {
        if (e.type != RenderGameOverlayEvent.ElementType.ALL || Minecraft.getMinecraft().thePlayer == null) return;
        for (Module m : modules) if (m.on) m.render();
    }
    @SubscribeEvent public void fov(FOVUpdateEvent e) { if (zoom != null && zoom.active()) e.newfov = e.fov / 4f; }
    // Mobil (touch) uchun: bosh menyu va pauza menyusida "Luvia" tugmasi
    @SubscribeEvent public void initGui(GuiScreenEvent.InitGuiEvent.Post e) {
        if (e.gui instanceof GuiMainMenu || e.gui instanceof GuiIngameMenu) e.buttonList.add(new GuiButton(9999, 4, 4, 70, 20, "\u00a7dLuvia"));
    }
    @SubscribeEvent public void action(GuiScreenEvent.ActionPerformedEvent.Post e) {
        if (e.button.id == 9999) Minecraft.getMinecraft().displayGuiScreen(new LuviaMenu());
    }
}
