package dev.luvia;
import java.io.IOException;
import java.util.*;
import net.minecraft.client.gui.Gui;
import net.minecraft.client.gui.GuiScreen;
public class LuviaMenu extends GuiScreen {
    static final String[] CATS = {"HUD", "Player", "Render"};
    static final int W = 400, H = 240;
    int sel = 0; Map<Module, Float> anim = new HashMap<>();
    int px() { return width / 2 - W / 2; } int py() { return height / 2 - H / 2; }
    List<Module> list() { List<Module> l = new ArrayList<>(); for (Module m : Luvia.modules) if (m.cat.equals(CATS[sel])) l.add(m); return l; }
    @Override public void drawScreen(int mx, int my, float pt) {
        Gui.drawRect(0, 0, width, height, 0xA0000000);
        int x = px(), y = py();
        Gfx.rrect(x - 1, y - 1, W + 2, H + 2, 12, 0xFF7C3AED);
        Gfx.rrect(x, y, W, H, 11, 0xFF140F24);
        Gfx.rrect(x + 6, y + 6, 104, H - 12, 8, Gfx.PANEL);
        Gfx.text("\u00a7dLuvia", x + 18, y + 16, 0xFFFFFFFF); Gfx.text("\u00a7fClient", x + 52, y + 16, 0xFFFFFFFF);
        Gui.drawRect(x + 16, y + 30, x + 100, y + 31, 0x557C3AED);
        for (int i = 0; i < CATS.length; i++) {
            int cy = y + 42 + i * 26; boolean hov = mx > x + 12 && mx < x + 104 && my > cy && my < cy + 22;
            if (i == sel) Gfx.rrect(x + 12, cy, 92, 22, 6, Gfx.ACCENT2); else if (hov) Gfx.rrect(x + 12, cy, 92, 22, 6, 0xFF2A2145);
            Gfx.text(CATS[i], x + 24, cy + 7, i == sel ? 0xFFFFFFFF : 0xFFB8AED6);
        }
        Gfx.text("RShift = menu", x + 16, y + H - 22, 0xFF6F6590);
        Gfx.text("\u00a7f" + CATS[sel], x + 122, y + 14, 0xFFFFFFFF);
        List<Module> l = list();
        for (int i = 0; i < l.size(); i++) {
            Module m = l.get(i); int ry = y + 32 + i * 30, rx = x + 120, rw = W - 130;
            boolean hov = mx > rx && mx < rx + rw && my > ry && my < ry + 26;
            Gfx.rrect(rx, ry, rw, 26, 7, hov ? 0xFF272040 : Gfx.PANEL);
            Gfx.text(m.name, rx + 10, ry + 9, 0xFFFFFFFF);
            float a = anim.getOrDefault(m, m.on ? 1f : 0f); a += ((m.on ? 1f : 0f) - a) * 0.25f; anim.put(m, a);
            int sx = rx + rw - 38, sy = ry + 7;
            Gfx.rrect(sx, sy, 28, 12, 6, Gfx.mix(Gfx.OFF, Gfx.ACCENT, a));
            Gfx.rrect(sx + 2 + (int) (16 * a), sy + 2, 8, 8, 4, 0xFFFFFFFF);
        }
        super.drawScreen(mx, my, pt);
    }
    @Override protected void mouseClicked(int mx, int my, int b) throws IOException {
        int x = px(), y = py();
        for (int i = 0; i < CATS.length; i++) { int cy = y + 42 + i * 26; if (mx > x + 12 && mx < x + 104 && my > cy && my < cy + 22) sel = i; }
        List<Module> l = list();
        for (int i = 0; i < l.size(); i++) { int ry = y + 32 + i * 30, rx = x + 120; if (mx > rx && mx < rx + W - 130 && my > ry && my < ry + 26) l.get(i).toggle(); }
        super.mouseClicked(mx, my, b);
    }
    @Override public boolean doesGuiPauseGame() { return false; }
}
