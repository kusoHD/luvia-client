package dev.luvia;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.Gui;
public class Gfx {
    public static final int ACCENT = 0xFFA78BFA, ACCENT2 = 0xFF7C3AED, BG = 0xE6140F24, PANEL = 0xFF1C1633, OFF = 0xFF3A3354;
    public static void rrect(int x, int y, int w, int h, int r, int c) {
        for (int i = 0; i < h; i++) {
            int d = i < r ? r - i : (i >= h - r ? i - (h - 1 - r) : 0), in = 0;
            if (d > 0) in = (int) (r - Math.sqrt(Math.max(0, r * r - d * d)));
            Gui.drawRect(x + in, y + i, x + w - in, y + i + 1, c);
        }
    }
    public static int mix(int a, int b, float t) {
        int r = 0;
        for (int s = 0; s <= 24; s += 8) { int ca = (a >> s) & 255, cb = (b >> s) & 255; r |= ((int) (ca + (cb - ca) * t) & 255) << s; }
        return r;
    }
    public static void text(String s, int x, int y, int c) { Minecraft.getMinecraft().fontRendererObj.drawStringWithShadow(s, x, y, c); }
    public static int width(String s) { return Minecraft.getMinecraft().fontRendererObj.getStringWidth(s); }
    public static void hud(int x, int y, String s) {
        int w = width(s) + 10; rrect(x, y, w, 16, 4, 0x90140F24); Gui.drawRect(x, y + 3, x + 2, y + 13, ACCENT); text(s, x + 6, y + 4, 0xFFFFFFFF);
    }
}
