package dev.luvia;
import java.util.*;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.Gui;
import net.minecraft.client.renderer.RenderHelper;
import net.minecraft.item.ItemStack;
import org.lwjgl.input.Keyboard;
import org.lwjgl.input.Mouse;
public class Modules {
    static Minecraft mc = Minecraft.getMinecraft();
    public static class Fps extends Module {
        public Fps() { super("FPS", "HUD", 6, 6); }
        public void render() { Gfx.hud(x, y, Minecraft.getDebugFPS() + " FPS"); }
    }
    public static class Cps extends Module {
        List<Long> l = new ArrayList<>(), r = new ArrayList<>(); boolean pl, pr;
        public Cps() { super("CPS", "HUD", 6, 26); }
        int c(List<Long> a) { long n = System.currentTimeMillis(); a.removeIf(t -> n - t > 1000); return a.size(); }
        public void render() {
            boolean bl = Mouse.isButtonDown(0), br = Mouse.isButtonDown(1);
            if (bl && !pl) l.add(System.currentTimeMillis()); if (br && !pr) r.add(System.currentTimeMillis()); pl = bl; pr = br;
            Gfx.hud(x, y, c(l) + " | " + c(r) + " CPS");
        }
    }
    public static class Coords extends Module {
        public Coords() { super("Coordinates", "HUD", 6, 46); }
        public void render() { Gfx.hud(x, y, String.format("XYZ %.0f %.0f %.0f", mc.thePlayer.posX, mc.thePlayer.posY, mc.thePlayer.posZ)); }
    }
    public static class Keys extends Module {
        public Keys() { super("Keystrokes", "HUD", 6, 70); }
        void key(int kx, int ky, int w, String s, boolean d) {
            Gfx.rrect(kx, ky, w, 20, 4, d ? Gfx.ACCENT2 : 0x90140F24); Gfx.text(s, kx + w / 2 - Gfx.width(s) / 2, ky + 6, 0xFFFFFFFF);
        }
        public void render() {
            key(x + 23, y, 20, "W", mc.gameSettings.keyBindForward.isKeyDown());
            key(x, y + 22, 20, "A", mc.gameSettings.keyBindLeft.isKeyDown());
            key(x + 23, y + 22, 20, "S", mc.gameSettings.keyBindBack.isKeyDown());
            key(x + 46, y + 22, 20, "D", mc.gameSettings.keyBindRight.isKeyDown());
            key(x, y + 44, 32, "LMB", Mouse.isButtonDown(0)); key(x + 34, y + 44, 32, "RMB", Mouse.isButtonDown(1));
        }
    }
    public static class Armor extends Module {
        public Armor() { super("Armor Status", "HUD", 6, 140); }
        public void render() {
            RenderHelper.enableGUIStandardItemLighting();
            for (int i = 0; i < 4; i++) {
                ItemStack s = mc.thePlayer.inventory.armorInventory[3 - i]; if (s == null) continue;
                mc.getRenderItem().renderItemAndEffectIntoGUI(s, x, y + i * 18);
                Gfx.text("" + (s.getMaxDamage() - s.getItemDamage()), x + 20, y + i * 18 + 4, 0xFFFFFFFF);
            }
            RenderHelper.disableStandardItemLighting();
        }
    }
    public static class Fullbright extends Module {
        float old;
        public Fullbright() { super("Fullbright", "Render", 0, 0); }
        public void onEnable() { old = mc.gameSettings.gammaSetting; mc.gameSettings.gammaSetting = 100f; }
        public void onDisable() { mc.gameSettings.gammaSetting = old; }
    }
    public static class Zoom extends Module {
        public Zoom() { super("Zoom (C)", "Render", 0, 0); }
        public boolean active() { return on && mc.currentScreen == null && Keyboard.isKeyDown(Keyboard.KEY_C); }
    }
    public static class ToggleSprint extends Module {
        public ToggleSprint() { super("Toggle Sprint", "Player", 6, 220); }
        public void tick() {
            if (mc.thePlayer != null && mc.gameSettings.keyBindForward.isKeyDown() && !mc.thePlayer.isSneaking() && !mc.thePlayer.isCollidedHorizontally) mc.thePlayer.setSprinting(true);
        }
        public void render() { Gfx.hud(x, mc.displayHeight / 2 - 20, "[Sprinting (Toggled)]"); }
    }
}
